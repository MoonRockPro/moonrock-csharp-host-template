<#
.SYNOPSIS
  Bootstrap MoonRock Packer: verify/install prerequisites, lay down folders, and (optionally) build & launch the GUI.
.DESCRIPTION
  This script checks for and installs:
    - .NET 8 SDK (dotnet)
    - PowerShell 7 (pwsh)
    - Git (for cloning the launcher template) [optional; ZIP fallback]
    - ConfuserEx (optional, for obfuscation)
  It then creates a simple working tree so you can drop .ps1 files and start packing.
.NOTES
  Run in an elevated PowerShell (Run as Administrator) for smooth winget/choco/scoop installs.
#>

param(
  [string]$BasePath = "$env:USERPROFILE\MoonRockPacker",
  [string]$TemplateRepoUrl = "https://github.com/G0WSIC/moonrock-csharp-host-template",
  [switch]$SkipInstall,
  [switch]$NoGUI
)

function Write-Section($t) { Write-Host "`n=== $t ===" -ForegroundColor Cyan }
function Test-Command($name) { $null -ne (Get-Command $name -ErrorAction SilentlyContinue) }

function Ensure-Winget {
  if (Test-Command winget) { return $true }
  Write-Warning "winget not found. Install the Microsoft Store 'App Installer' manually if automatic install fails."
  return $false
}

function Try-Install {
  param(
    [string]$Tool,
    [string]$WingetId,
    [string]$ChocoId,
    [string]$ScoopId
  )
  $ok = $false

  if (Ensure-Winget) {
    try {
      Write-Host ("winget installing {0}..." -f $Tool) -ForegroundColor Yellow
      winget install --id $WingetId --silent --accept-package-agreements --accept-source-agreements
      $ok = $true
    } catch {
      Write-Warning ("winget failed for {0}: {1}" -f $Tool, $_)
    }
  }

  if (-not $ok -and (Test-Command choco)) {
    try {
      Write-Host ("choco installing {0}..." -f $Tool) -ForegroundColor Yellow
      choco install $ChocoId -y
      $ok = $true
    } catch {
      Write-Warning ("choco failed for {0}: {1}" -f $Tool, $_)
    }
  }

  if (-not $ok -and (Test-Command scoop)) {
    try {
      if (-not (scoop bucket list | Select-String extras)) { scoop bucket add extras | Out-Null }
      Write-Host ("scoop installing {0}..." -f $Tool) -ForegroundColor Yellow
      scoop install $ScoopId
      $ok = $true
    } catch {
      Write-Warning ("scoop failed for {0}: {1}" -f $Tool, $_)
    }
  }

  return $ok
}

function Ensure-DotNet {
  if (Test-Command dotnet) {
    try {
      $ver = (& dotnet --version) 2>$null
      Write-Host "dotnet version: $ver"
      if ($ver -match '^8\.') { return $true }
    } catch {}
  }
  return (Try-Install -Tool ".NET 8 SDK" -WingetId "Microsoft.DotNet.SDK.8" -ChocoId "dotnet-8.0-sdk" -ScoopId "dotnet-sdk")
}

function Ensure-PowerShell7 {
  if (Test-Command pwsh) { return $true }
  return (Try-Install -Tool "PowerShell 7" -WingetId "Microsoft.PowerShell" -ChocoId "powershell-core" -ScoopId "powershell")
}

function Ensure-Git {
  if (Test-Command git) { return $true }
  return (Try-Install -Tool "Git" -WingetId "Git.Git" -ChocoId "git" -ScoopId "git")
}

function Ensure-ConfuserEx {
  # Optional; GUI can run without it.
  if (Test-Command confuser.cli) { return $true }
  $ok = Try-Install -Tool "ConfuserEx" -WingetId "mkaring.ConfuserEx" -ChocoId "confuserex" -ScoopId "confuserex"
  if (-not $ok) { Write-Warning "ConfuserEx not installed automatically. You can install it later (winget/choco/scoop)." }
  return $ok
}

function Ensure-Folders {
  New-Item -ItemType Directory -Force -Path $BasePath, "$BasePath\ps-scripts", "$BasePath\output", "$BasePath\confuser" | Out-Null
  if (-not (Test-Path "$BasePath\ps-scripts\README.txt")) {
@"
Drop your .ps1 files in this folder.
The GUI and Pack-PowerShell.ps1 will look here by default.
"@ | Set-Content -Encoding UTF8 "$BasePath\ps-scripts\README.txt"
  }
}

function Clone-Template {
  param([string]$Dst = "$BasePath\moonrock-csharp-host-template")
  if (Test-Path $Dst) { Write-Host "Template already exists at $Dst"; return $Dst }

  if (Test-Command git) {
    Write-Host "Cloning template from $TemplateRepoUrl ..." -ForegroundColor Yellow
    git clone --depth 1 $TemplateRepoUrl $Dst | Out-Null
    return $Dst
  }

  Write-Warning "Git not found. Falling back to ZIP download."
  try {
    # Try 'main' first, then 'master'
    $zipCandidates = @(
      ($TemplateRepoUrl.TrimEnd('/')) + "/archive/refs/heads/main.zip",
      ($TemplateRepoUrl.TrimEnd('/')) + "/archive/refs/heads/master.zip"
    )
    $tmpZip = Join-Path $env:TEMP ("moonrock-template-" + [Guid]::NewGuid().ToString() + ".zip")
    $tmpDir = Join-Path $env:TEMP ("moonrock-template-" + [Guid]::NewGuid().ToString())

    $downloaded = $false
    foreach ($zipUrl in $zipCandidates) {
      try {
        Write-Host "Downloading $zipUrl ..." -ForegroundColor Yellow
        Invoke-WebRequest -Uri $zipUrl -OutFile $tmpZip -UseBasicParsing
        $downloaded = $true
        break
      } catch {}
    }
    if (-not $downloaded) { throw "Could not download repo ZIP (tried main and master)." }

    Write-Host "Extracting..." -ForegroundColor Yellow
    Expand-Archive -Path $tmpZip -DestinationPath $tmpDir -Force

    # Move extracted folder contents to $Dst (GitHub names it <repo>-<branch>)
    $sub = Get-ChildItem -Path $tmpDir | Where-Object { $_.PSIsContainer } | Select-Object -First 1
    if (-not $sub) { throw "Could not find extracted folder contents." }
    New-Item -ItemType Directory -Force -Path $Dst | Out-Null
    Copy-Item -Path (Join-Path $sub.FullName '*') -Destination $Dst -Recurse -Force

    Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
    Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host "Template fetched to $Dst" -ForegroundColor Green
    return $Dst
  }
  catch {
    throw "Failed to fetch template: $($_.Exception.Message)"
  }
}

function Build-GUI {
  param([string]$SolutionRoot)
  $guiPath = Join-Path $SolutionRoot "src\MoonRock.Packer.GUI"
  if (-not (Test-Path $guiPath)) {
    Write-Warning "MoonRock.Packer.GUI not found under $SolutionRoot\src. Skipping GUI build."
    return $null
  }
  Write-Section "Building MoonRock.Packer.GUI"
  dotnet build $guiPath -c Release | Write-Host
  $exe = Join-Path $guiPath "bin\Release\net8.0-windows\MoonRock.Packer.GUI.exe"
  if (Test-Path $exe) {
    Write-Host "GUI built: $exe" -ForegroundColor Green
    return $exe
  }
  Write-Warning "GUI build did not produce the expected EXE."
  return $null
}

# --- MAIN ---
Write-Section "MoonRock Packer Bootstrap"

if (-not $SkipInstall) {
  Write-Section "Checking prerequisites"
  $ok = $true
  $ok = (Ensure-DotNet) -and $ok
  $ok = (Ensure-PowerShell7) -and $ok
  $ok = (Ensure-Git) -and $ok
  Ensure-ConfuserEx | Out-Null
  if (-not $ok) {
    Write-Warning "Some prerequisites failed to install automatically. You can run the script again after fixing."
  }
} else {
  Write-Host "Skipping installs (-SkipInstall)."
}

Ensure-Folders
$TemplateRoot = Clone-Template

# Make a convenience pack script that targets the ps-scripts folder
$packScript = @'
param(
  [string]$ScriptPath = "$env:USERPROFILE\MoonRockPacker\ps-scripts",
  [string]$TemplateRoot = "$env:USERPROFILE\MoonRockPacker\moonrock-csharp-host-template",
  [string]$OutputDir = "$env:USERPROFILE\MoonRockPacker\output"
)
Write-Host "Packing using TemplateRoot: $TemplateRoot"
if (-not (Test-Path $TemplateRoot)) { throw "TemplateRoot not found: $TemplateRoot" }

# Simple heuristic: if ScriptPath is a directory, pick the newest .ps1 in it
if (Test-Path $ScriptPath -PathType Container) {
  $latest = Get-ChildItem -Path $ScriptPath -Filter *.ps1 | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $latest) { throw "No .ps1 found in $ScriptPath" }
  $ScriptPath = $latest.FullName
}

# Set MOONROCK_KEY if not already set (DEV KEY: change for production)
if (-not $env:MOONROCK_KEY) {
  $env:MOONROCK_KEY = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("changeme-dev-key"))
  Write-Warning "MOONROCK_KEY not found; set a temporary dev key. Replace before distribution."
}

# Build launcher
pushd $TemplateRoot
dotnet build .\src\MoonRock.Launcher -c Release
# Do a publish, placing binaries in output
dotnet publish .\src\MoonRock.Launcher -c Release -r win-x64 -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $OutputDir
popd

Write-Host "Publish completed to: $OutputDir"
'@
$packPath = Join-Path $BasePath "Pack-PowerShell.ps1"
$packScript | Set-Content -Encoding UTF8 $packPath

# Optionally build and launch GUI
if (-not $NoGUI) {
  $guiExe = Build-GUI -SolutionRoot $TemplateRoot
  if ($guiExe) {
    Write-Host "Launching GUI..." -ForegroundColor Cyan
    Start-Process $guiExe
  } else {
    Write-Warning "GUI not launched (build issue). You can run it later after fixing the template path."
  }
}

Write-Host ("`nAll set. Put your .ps1 into {0}\ps-scripts then run:`n  {1}" -f $BasePath, $packPath) -ForegroundColor Green
