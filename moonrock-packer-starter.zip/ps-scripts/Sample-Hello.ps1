Write-Host "Hello from a sample PowerShell script!"
Start-Sleep -Seconds 1
Write-Host "Arguments: $args"
