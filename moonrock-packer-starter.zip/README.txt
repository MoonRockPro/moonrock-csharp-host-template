MoonRock Packer Starter
========================

1) Run `Setup-MoonRockPacker.ps1` in an elevated PowerShell.
   - It installs .NET 8 SDK, PowerShell 7, Git, and (optionally) ConfuserEx.
   - It clones the launcher template and builds the GUI.
   - It creates:
       \ps-scripts  -> drop your .ps1 files here
       \output      -> built EXEs land here
       \confuser    -> a starter ConfuserEx project

2) Drop your .ps1 into `ps-scripts`. The newest file is used by `Pack-PowerShell.ps1`.

3) Run `Pack-PowerShell.ps1` (or use the GUI the setup launches).

Notes:
- Set a real MOONROCK_KEY in your user env for production:
    [Environment]::SetEnvironmentVariable("MOONROCK_KEY","<YOUR-KEY>", "User")
- ConfuserEx is optional; you can add stronger protections later.
