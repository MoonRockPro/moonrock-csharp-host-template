param(
  [Parameter(Mandatory=$true)][string]$InputScript,
  [Parameter(Mandatory=$true)][string]$OutFile
)

if (-not (Test-Path $InputScript)) { throw "Script not found: $InputScript" }
$keyB64 = $env:MOONROCK_KEY
if (-not $keyB64) {
  Write-Warning "MOONROCK_KEY not set; using DEV key."
  $keyB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("changeme-dev-key"))
}
$key = [Convert]::FromBase64String($keyB64)
if ($key.Length -ne 32) { throw "MOONROCK_KEY must decode to 32 bytes (use base64)." }

$plain = [IO.File]::ReadAllText($InputScript, [Text.Encoding]::UTF8)
$bytes = [Text.Encoding]::UTF8.GetBytes($plain)

$nonce = New-Object byte[] 12
[Security.Cryptography.RandomNumberGenerator]::Fill($nonce)
$cipher = New-Object byte[] $bytes.Length
$tag    = New-Object byte[] 16

$aes = [Security.Cryptography.AesGcm]::new($key)
$aes.Encrypt($nonce, $bytes, $cipher, $tag)
$aes.Dispose()

$obj = [ordered]@{
  NonceB64 = [Convert]::ToBase64String($nonce)
  TagB64   = [Convert]::ToBase64String($tag)
  DataB64  = [Convert]::ToBase64String($cipher)
}
[IO.File]::WriteAllText($OutFile, (ConvertTo-Json $obj -Depth 3), [Text.Encoding]::UTF8)
Write-Host "Wrote: $OutFile"
