using System;
using System.Security.Cryptography;

namespace MoonRock.Launcher.Crypto
{
    public static class AesGcmUtil
    {
        public static byte[] Decrypt(byte[] key, byte[] nonce, byte[] tag, byte[] ciphertext)
        {
            var plaintext = new byte[ciphertext.Length];
            using var aes = new AesGcm(key);
            aes.Decrypt(nonce, ciphertext, tag, plaintext);
            return plaintext;
        }
    }
}
