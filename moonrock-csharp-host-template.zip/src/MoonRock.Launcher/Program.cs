using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using MoonRock.Launcher.Crypto;

public class PayloadEnvelope
{
    public string? NonceB64 { get; set; }
    public string? TagB64 { get; set; }
    public string? DataB64 { get; set; }
}

internal class Program
{
    static int Main(string[] args)
    {
        try
        {
            var keyB64 = Environment.GetEnvironmentVariable("MOONROCK_KEY");
            if (string.IsNullOrWhiteSpace(keyB64))
            {
                Console.Error.WriteLine("MOONROCK_KEY not set.");
                return 2;
            }
            byte[] key = Convert.FromBase64String(keyB64);

            var exeDir = AppContext.BaseDirectory;
            var payloadPath = Path.Combine(exeDir, "payload.json");
            if (!File.Exists(payloadPath))
            {
                Console.Error.WriteLine($"payload.json not found at: {payloadPath}");
                return 3;
            }

            var json = File.ReadAllText(payloadPath, Encoding.UTF8);
            var env = JsonSerializer.Deserialize<PayloadEnvelope>(json) ?? throw new Exception("Bad payload.json");
            byte[] nonce = Convert.FromBase64String(env.NonceB64!);
            byte[] tag   = Convert.FromBase64String(env.TagB64!);
            byte[] data  = Convert.FromBase64String(env.DataB64!);

            var psBytes = MoonRock.Launcher.Crypto.AesGcmUtil.Decrypt(key, nonce, tag, data);
            var psText  = Encoding.UTF8.GetString(psBytes);

            using var rs = RunspaceFactory.CreateRunspace();
            rs.Open();
            using var ps = PowerShell.Create();
            ps.Runspace = rs;
            ps.AddScript(psText);
            foreach (var a in args) ps.AddArgument(a);

            var results = ps.Invoke();
            if (ps.HadErrors)
            {
                foreach (var e in ps.Streams.Error) Console.Error.WriteLine(e.ToString());
                return 4;
            }
            foreach (var r in results) Console.WriteLine(r?.ToString());
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex.ToString());
            return 1;
        }
    }
}
