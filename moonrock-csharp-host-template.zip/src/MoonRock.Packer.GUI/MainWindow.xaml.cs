using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using Microsoft.Win32;

namespace MoonRock.Packer.GUI
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            TxtOut.Text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "MoonRockPacker", "output");
            TxtTpl.Text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "MoonRockPacker", "moonrock-csharp-host-template");
        }

        void BrowseScript(object s, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "PowerShell (*.ps1)|*.ps1" };
            if (dlg.ShowDialog() == true) TxtScript.Text = dlg.FileName;
        }
        void BrowseOut(object s, RoutedEventArgs e)
        {
            TxtOut.Text = PickFolder(TxtOut.Text);
        }
        void BrowseTpl(object s, RoutedEventArgs e)
        {
            TxtTpl.Text = PickFolder(TxtTpl.Text);
        }
        string PickFolder(string start)
        {
            var dlg = new System.Windows.Forms.FolderBrowserDialog { SelectedPath = start };
            return dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK ? dlg.SelectedPath : start;
        }

        void Log(string s) => TxtLog.AppendText(s + Environment.NewLine);

        async void BuildClick(object s, RoutedEventArgs e)
        {
            try
            {
                var ps1 = TxtScript.Text;
                var tpl = TxtTpl.Text;
                var outDir = TxtOut.Text;
                if (!File.Exists(ps1)) { Log("Script not found."); return; }
                Directory.CreateDirectory(outDir);

                // 1) Encrypt PS1 -> payload.json
                var enc = Path.Combine(tpl, "tools", "Encrypt-PS1.ps1");
                if (!File.Exists(enc)) { Log("Encrypt-PS1.ps1 missing."); return; }
                Log("Encrypting script...");
                var encOk = await RunPwsh(enc, $"-InputScript "{ps1}" -OutFile "{Path.Combine(outDir, "payload.json")}"");
                if (!encOk) { Log("Encryption failed."); return; }

                // 2) Publish Launcher
                Log("Publishing launcher...");
                if (!await RunDotnet("publish", $""{Path.Combine(tpl, "src", "MoonRock.Launcher")}" -c Release -r win-x64 -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o "{outDir}""))
                { Log("Publish failed."); return; }

                Log("Done.");
            }
            catch (Exception ex) { Log(ex.ToString()); }
        }

        void CloseClick(object s, RoutedEventArgs e) => Close();

        async System.Threading.Tasks.Task<bool> RunPwsh(string script, string args)
        {
            return await RunProcess("pwsh", $"-NoProfile -ExecutionPolicy Bypass -File "{script}" {args}");
        }
        async System.Threading.Tasks.Task<bool> RunDotnet(string cmd, string args)
        {
            return await RunProcess("dotnet", $"{cmd} {args}");
        }

        async System.Threading.Tasks.Task<bool> RunProcess(string file, string args)
        {
            var psi = new ProcessStartInfo(file, args) { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
            var p = Process.Start(psi)!;
            p.OutputDataReceived += (_, e) => { if (e.Data != null) Log(e.Data); };
            p.ErrorDataReceived  += (_, e) => { if (e.Data != null) Log(e.Data); };
            p.BeginOutputReadLine(); p.BeginErrorReadLine();
            await p.WaitForExitAsync();
            return p.ExitCode == 0;
        }
    }
}
