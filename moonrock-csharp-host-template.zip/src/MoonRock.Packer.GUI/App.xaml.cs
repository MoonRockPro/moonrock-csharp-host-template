using System.Windows;
namespace MoonRock.Packer.GUI { public partial class App : Application { } }
