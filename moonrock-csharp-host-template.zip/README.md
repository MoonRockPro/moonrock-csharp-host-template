# MoonRock C# Host Template

This repo contains:
- **MoonRock.Launcher** (.NET 8): a small host that decrypts and runs an encrypted PowerShell script.
- **MoonRock.Packer.GUI** (WPF): optional GUI packer that encrypts a .ps1 and publishes the launcher.
- **tools**: helper scripts (e.g., Encrypt-PS1.ps1).

## Build
- Install .NET 8 SDK and PowerShell 7.
- `dotnet build ./src/MoonRock.Launcher -c Release`
- (Optional) `dotnet build ./src/MoonRock.Packer.GUI -c Release`

## Usage
1. Set `MOONROCK_KEY` (Base64, 32 bytes after decoding).
2. Run `tools/Encrypt-PS1.ps1 -InputScript your.ps1 -OutFile payload.json`
3. Copy `payload.json` next to the published EXE, then run the EXE.
